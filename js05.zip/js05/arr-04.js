/* Напишите функцию oddMax(A), возвращающую максимальный нечет-
ный элемент в массиве натуральных чисел A, или undefined,
если в нем нет нечетных элементов. */

function oddMax(a) {
  let max = 0;
  for (let i = 0; i < a.length; i++) {
    if (a[i] % 2 != 0 && a[i] > max) max = a[i];
  }
  if (max == 0) return undefined;
  else return max;
}

module.exports = oddMax;
