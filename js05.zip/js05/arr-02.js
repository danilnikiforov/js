/* Напишите функцию f(A), принимающую массив действительных чисел,
и возвращающую массив из трех чисел: количества отрицательных,
положительных и нулевых элементов в указанном порядке.

Пример: f([9,‐5,0,‐2,8,‐1], 6) равно [3,1,2]. */

function SortNumbers(array) {
  let CountedArray = [0, 0, 0];
  for (let i = 0; i < array.length; i++) {
    if (array[i] < 0) CountedArray[0] += 1;
    else if (array[i] == 0) CountedArray[1] += 1;
    else CountedArray[2] += 1;
  }
  return CountedArray;
}

module.exports = SortNumbers;
