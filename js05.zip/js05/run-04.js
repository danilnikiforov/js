/* Напишите функцию oddMax(A), возвращающую максимальный нечет-
ный элемент в массиве натуральных чисел A, или undefined,
если в нем нет нечетных элементов. */

let oddMax = require('./arr-04.js');
const assert = require('assert');

let a = [1,2,3,4,5,6];
let b = [2, 0, 4, 6, 10];
let c = [1, 2213513430, 1004, 241024, 100020304, 102103102319200];

assert.deepStrictEqual(oddMax(a), 5, "Ошибка, плохой код, решай заново");
assert.deepStrictEqual(oddMax(b), undefined, "Ошибка, плохой код, решай заново");
assert.deepStrictEqual(oddMax(c), 1, "Ошибка, плохой код, решай заново");
