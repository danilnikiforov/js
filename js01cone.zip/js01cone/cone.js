function solve() {
	// получаем данные в виде строк из полей ввода на странице
	let d1 = document.getElementById("d1").value;
	let d2 = document.getElementById("d2").value;
	let h = document.getElementById("h").value;

	alert(coneVolume(d1, d2, h));
}

function coneVolume(d1, d2, h){
	// проверяем данные
	if (d1 != parseInt(d1) || d1<0 || d2 != parseInt(d2) || d2<0) return 'Недопустимые данные';

	// вычисление объема усеченного конуса
	let r1 = d1/2, r2 = d2/2;
	return Math.PI * h * (r1*r1 + r1*r2 + r2*r2) / 3;
}
