// холст для рисования - игровое поле
let board = document.getElementById('cnv').getContext('2d');
let boardObject = document.getElementById('cnv');

// фоновая клетка 32×32 - трава
let bg = document.getElementById('grass');

// персонаж, спрайт 32×32 – привидение из пакмана
let char = document.getElementById('ghost');

// координаты персонажа, столбец и строка, считая с нуля
let ghostCol = 0, ghostRow = 0;

// абзац с сообщением 
let msg = document.getElementById('msg');

// препятствие (одно) (а можно было накодить много...)
// координаты как у персонажа
let obstacleCol = 3, obstacleRow = 4;

// препятствие - кустик
let obstacle = document.getElementById('bush');

// константы
const maxColumns = 16;
const maxRows = 10;
const gridSize = 32;

// после загрузки картинок рисуем начальное состояние поля
function init() {
	for (let col = 0; col < maxColumns; col++) {
		for (let row = 0; row < maxRows; row++) {
			board.drawImage(bg, col*gridSize, row*gridSize);
		}
		if (col === ghostCol) board.drawImage(char, ghostCol*gridSize, ghostRow*gridSize);
		if (col === obstacleCol) board.drawImage(obstacle, obstacleCol*gridSize, obstacleRow*gridSize); // рисуем препятствие
	}	
};

function moveOnce(event) {
	let cnvBorder = boardObject.getBoundingClientRect(); // получаем границы канваса на странице
	console.log(cnvBorder.top, cnvBorder.right, cnvBorder.bottom, cnvBorder.left); // дебага

	// движение вправо
	// проверяем место клика - строго справа, проверяем нажатую клавишу
	if (event.clientX > cnvBorder.right && event.clientY > cnvBorder.top && event.clientY < cnvBorder.bottom || event.key === "d" || event.key === "ArrowRight") {
		 // проверяем границы поля, проверяем несовпадение новых координат персонажа и координат препятствия
		if (ghostCol < maxColumns-1 && (ghostCol+1 !== obstacleCol || ghostRow !== obstacleRow)) {
			board.drawImage(bg, ghostCol*gridSize, ghostRow*gridSize); // закрашиваем прежнее место
			ghostCol++; // обновляем позицию привидения
		}	
	}

	// движение влево
	if (event.clientX < cnvBorder.left && event.clientY > cnvBorder.top && event.clientY < cnvBorder.bottom || event.key === "a" || event.key === "ArrowLeft") {
		if (ghostCol > 0 && (ghostCol-1 !== obstacleCol || ghostRow !== obstacleRow)) {
			board.drawImage(bg, ghostCol*gridSize, ghostRow*gridSize);
			ghostCol--;
		}	
	}

	// движение вверх
	if (event.clientY < cnvBorder.top && event.clientX > cnvBorder.left && event.clientX < cnvBorder.right || event.key === "w" || event.key === "ArrowUp") {
		if (ghostRow > 0 && (ghostRow-1 !== obstacleRow || ghostCol !== obstacleCol)) {
			board.drawImage(bg, ghostCol*gridSize, ghostRow*gridSize);
			ghostRow--;
		}	
	}

	// движение вниз
	if (event.clientY > cnvBorder.bottom && event.clientX > cnvBorder.left && event.clientX < cnvBorder.right || event.key === "s" || event.key === "ArrowDown") {
		if (ghostRow < maxRows-1 && (ghostRow+1 !== obstacleRow || ghostCol !== obstacleCol)) {
			board.drawImage(bg, ghostCol*gridSize, ghostRow*gridSize);
			ghostRow++;
		}	
	}

	// обновляем спрайт персонажа
	board.drawImage(char, ghostCol*gridSize, ghostRow*gridSize);

	if (event.type == "mouseup") {
		msg.value = "Клик в "+ event.clientX + ", "+ event.clientY +"!";
	}
}
	
window.onload = init;
document.onmouseup = moveOnce;
document.onkeyup = moveOnce;
