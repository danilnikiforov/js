function S (x1,y1,x2,y2,x3,y3){
   //Для определения тупоугольного треугольника нужно найти стороны a b c  
    let a = Math.sqrt( (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1) );
    let b = Math.sqrt( (x3-x2)*(x3-x2)  + (y3-y2)*(y3-y2) );
    let c = Math.sqrt( (x1-x3)*(x1-x3)  + (y1-y3)*(y1-y3) );
    let A = a*a;
    let B = b*b;
    let C = c*c;
    if (A + B < C || A + C < B || B + C < A){
        //Используем формулу Герона
        return Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2)+(x3-y3)*(x3-y3));
    }
    else {
        return -1;
    }
}
console.log (S(1,3,2,6,3,8));
