function maxmin (a,b,c,d) {
    return Math.max(Math.min(Math.abs(a), Math.abs(b)), Math.max(Math.abs(c), Math.abs(d)));
}
console.log(maxmin(1,2,3,4));