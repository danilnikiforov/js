function WeekdayName(n){
    switch (n) {
        case 1:
            return 'понедельник' ;
        case 2:
            return 'вторник';
        case 3:
            return 'среда';
        case 4:
            return 'четверг';
        case 5:
            return 'пятница';
        case 6:
            return 'суббота';
        case 7:
            return 'воскресенье';
        default:
          return '';
    }
} 
console.log(WeekdayName(4));
