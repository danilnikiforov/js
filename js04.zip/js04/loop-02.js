function pyramid(n) {
	let res;
	for (let i = 0; i < n; i++) {
	  res = ""
	//цикл пробелов
	  for (let j = 0; j <n-i-1; j++) {
	    res+=" ";
	  }
	// цикл решёток
	  for (let r = 0; r<1+i*2; r++) {
	    res+="#";
	  }
	  console.log(res);
	}
	return `пирамида из ${n} строк` 
}

module.exports = pyramid;
