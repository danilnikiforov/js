// Напишите программу, которая напечатает 100 строк Hello world!
// при помощи цикла for.

for (let i = 0; i < 100; i++) {
  console.log("Hello World!");
}

let i = 0;
while (i < 100) {
  console.log("Hello World!");
  i++;
}

let i = 0;
do {
  console.log("Hello World!");
  i++;
} while (i < 100);
