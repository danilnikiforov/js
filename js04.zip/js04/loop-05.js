function expDiff(x) {
    let sum = 1;
    let fact = 1;
    let p = 1;
    let k = 0.0001;
          for(let i = 1; i < 1000; i++){
              fact *= i;
              p*=x;
              if (Math.abs(p/fact) >= k) sum += 1/fact;
              else break;
          }

    return (Math.exp(x)-Math.abs(sum));
    
}

module.exports = expDiff;