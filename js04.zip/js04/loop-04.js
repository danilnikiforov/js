
function checkCardNumber(nstr) {
  nstr = String(nstr);
  let check = false;
  if (nstr.length >= 13 && nstr.length <= 16) {
    let m = 0 , o = 0;
    for (let i = 0; i < nstr.length; i++) {
      let digit = Number(nstr[nstr.length - (i+1)]);
      if (i % 2 == 0) {
        o += digit;
      } else {
        if (digit*2 < 10)
        m = m + digit*2;
        else {
          let k = digit*2;
          m = m + k % 10 + 1;
        }
      }
    }
    if ((m+o)%10==0) check = true;
  }
  return check;
}
console.log(checkCardNumber(nstr));
module.exports = checkCardNumber;
