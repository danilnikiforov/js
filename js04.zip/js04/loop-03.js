function gcd(m,n) {
	let d = 0, res = 0;
  if (m > n) d = n; else d = m;
  for (let i = 0; i<=d; i++) {
    if (m % i == 0 && n % i == 0) r = i;
  }
  return res;
}

module.exports = gcd;
